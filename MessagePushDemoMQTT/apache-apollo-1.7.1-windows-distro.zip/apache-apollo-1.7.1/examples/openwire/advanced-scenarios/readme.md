## Overview

This is an example of how use the OpenWire Java implementation with Apollo.

## Prereqs

- Install Java SDK
- Install [Maven](http://maven.apache.org/download.html) 

## Building

Run:

    mvn install

## Running the Examples

All of these examples require an externally running Apollo broker with a tcp connector
listening on port 61613
